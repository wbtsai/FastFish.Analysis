﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Docx")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Docx")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Allow the UnitTests to get at internal stuff.
[assembly: InternalsVisibleTo("UnitTests, PublicKey=00240000048000009400000006020000002400005253413100040000010001006385bc4fde8d1ddaabf50fca5a7c9fd10cbdc792f9b026945c563221f2799649a4271852f7c2dab8259f8c907e1f45e1643369c85584a8b16cc4763992f897797dd57b03a176f76f507f472075a0026c05f90ff99234a3eec16b1c98bbc987d1b67893a7af1d5b980d5b901a8b8c2665cb4a79eb63e2f897c94d8c1b9ac488ac")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("16123f21-f3d1-47bb-ae9a-eb7c82c0f3c8")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.1.13")]
[assembly: AssemblyFileVersion("1.0.1.13")]