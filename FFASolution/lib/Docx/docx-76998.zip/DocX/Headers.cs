﻿namespace Novacode
{
    public class Headers
    {
        internal Headers()
        { 
        }

        public Header odd;
        public Header even;
        public Header first;
    }
}
