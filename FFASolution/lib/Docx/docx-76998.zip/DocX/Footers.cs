﻿namespace Novacode
{
    public class Footers
    {
        internal Footers()
        {
            
        }

        public Footer odd;
        public Footer even;
        public Footer first;
    }
}
